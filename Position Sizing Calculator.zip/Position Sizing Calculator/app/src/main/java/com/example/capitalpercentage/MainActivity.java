package com.example.capitalpercentage;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText e1, e2,e3,e4;
    TextView t1;
    int num1, num2,num3,num4;
    Button ac;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        ac=(Button)findViewById(R.id.ac);

        ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                e1.setText("");
                e2.setText("");
                e3.setText("");
                e4.setText("");
               t1.setText("Lots you can buy");


            }
        });

    }

    // a public method to get the input numbers
    public boolean getNumbers() {

        // defining the edit text 1 to e1
        e1 = (EditText) findViewById(R.id.num1);

        // defining the edit text 2 to e2
        e2 = (EditText) findViewById(R.id.num2);
        e3 = (EditText) findViewById(R.id.num3);
        e4 = (EditText) findViewById(R.id.num4);

        // defining the text view to t1
        t1 = (TextView) findViewById(R.id.result);

        // taking input from text box 1
        String s1 = e1.getText().toString();

        // taking input from text box 2
        String s2 = e2.getText().toString();
        String s3 = e3.getText().toString();
        String s4 = e4.getText().toString();

        // condition to check if box is not empty
        if (((s1.equals(null))|| (s1.equals("") )) ||((s2.equals(null))|| (s2.equals("") ))||((s3.equals(null))|| (s3.equals("") ))||((s4.equals(null))|| (s4.equals("") )) ){

            String result = "Please enter a value";
            t1.setText(result);

            return false;
        } else {
            // converting string to int.
            num1 = Integer.parseInt(s1);

            // converting string to int.
            num2 = Integer.parseInt(s2);
            num3 = Integer.parseInt(s3);
            num4 = Integer.parseInt(s4);
        }

        return true;
    }

    // a public method to perform addition

    public void answer(View v) {

        // get the input numbers
        if (getNumbers()) {

            // displaying the text in text view assigned as t1
            float sum = num4/(((num1*num2)*100)/num3);
            t1.setText(Float.toString(sum));
        }
    }
/*    public void ac(View v) {

        // get the input numbers
        if (getNumbers()) {

            // displaying the text in text view assigned as t1
            float sum = 0;
            t1.setText(Float.toString(sum));
            e1.setText(Float.toString(sum));
            e2.setText(Float.toString(sum));
            e3.setText(Float.toString(sum));
            e4.setText(Float.toString(sum));

        }
    }*/



}